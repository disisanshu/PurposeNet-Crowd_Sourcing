$(document).ready(function() {
  var y=1;
  var n=0;
  $("#yes1").click(function() {
   $.ajax({
       url:'api.php',
       data:y,
       success:function(data) {
       $("#yes1").fadeOut();
       $("#no1").fadeOut();
       $(".oa").html("you told it was Batman");
       }
     });

   });
  $("#no1").click(function() {
       $("#yes1").fadeOut();
       $("#no1").fadeOut();
       $(".ob").html("you told it was Joker");
    });

  

});
