<?php

session_destroy();

?>
